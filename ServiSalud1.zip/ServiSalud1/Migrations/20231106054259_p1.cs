﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace ServiSalud1.Migrations
{
    /// <inheritdoc />
    public partial class p1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Clinica",
                columns: new[] { "Id_Clinica", "Nombre_clinica", "Ubicacion" },
                values: new object[,]
                {
                    { 101, "SERVISALUD CESPEDES", "Tomaykichwa" },
                    { 102, "SERVISALUD CESPEDES", "Lima" }
                });

            migrationBuilder.InsertData(
                table: "Equipo_produccion",
                columns: new[] { "Id_equipo", "Nombre_equipo" },
                values: new object[,]
                {
                    { 220, "Esfingomanometro" },
                    { 221, "Termostato" },
                    { 222, "Rayos X" },
                    { 223, "Guantes Latex" },
                    { 224, "Ultra sonido" },
                    { 225, "Estetoscopio" },
                    { 226, "Tensiometro Aneroide" },
                    { 227, "Sillones reclinables" },
                    { 228, "Computadora" },
                    { 229, "Bascula" }
                });

            migrationBuilder.InsertData(
                table: "Especialidad",
                columns: new[] { "Id_especialidad", "Especialidad_nombre" },
                values: new object[,]
                {
                    { 4120, "Reumatología" },
                    { 4121, "Dermatología" },
                    { 4122, "Enfermería" },
                    { 4123, "Cardiología" },
                    { 4124, "Nutrición" },
                    { 4125, "Endocrinología" },
                    { 4126, "Neurología" },
                    { 4127, "Traumatología" },
                    { 4128, "Terapia" },
                    { 4129, "Psicología" }
                });

            migrationBuilder.InsertData(
                table: "Historial_Clinico",
                columns: new[] { "Id_historial", "Alergias", "Fecha_ingreso" },
                values: new object[,]
                {
                    { 851, "Aines", new DateTime(2023, 11, 6, 0, 0, 0, 0, DateTimeKind.Local) },
                    { 852, "-", new DateTime(2023, 11, 6, 0, 0, 0, 0, DateTimeKind.Local) }
                });

            migrationBuilder.InsertData(
                table: "Usuario",
                columns: new[] { "Id_Usuario", "Apellido", "Contra", "Nombre", "TipoUsuario" },
                values: new object[,]
                {
                    { "admin", "Cornejo", "admin", "Adrian", "Administrador" },
                    { "LQuispe", "Quispe", "12345", "Luis", "Empleado" },
                    { "Spiderman", "Parker", "12345", "Peter", "Paciente" }
                });

            migrationBuilder.InsertData(
                table: "Citas",
                columns: new[] { "Id_citas", "Fechas_citas", "Id_especialidad", "Id_historial" },
                values: new object[] { 9621, new DateTime(2023, 1, 25, 14, 30, 0, 0, DateTimeKind.Unspecified), 4121, 851 });

            migrationBuilder.InsertData(
                table: "Empleados",
                columns: new[] { "Id_empleado", "Id_Clinica", "Id_especialidad", "Nacimiento", "Nombre_empleado", "Sexo", "Telefono" },
                values: new object[,]
                {
                    { 202001, 102, 4121, new DateTime(1990, 5, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), "Carlos Vasquez", "M", 941449558 },
                    { 202002, 101, 4120, new DateTime(1981, 7, 8, 0, 0, 0, 0, DateTimeKind.Unspecified), "Luis Quispe", "M", 941449544 },
                    { 202003, 102, 4122, new DateTime(1975, 1, 11, 0, 0, 0, 0, DateTimeKind.Unspecified), "Ernesto Vargas", "M", 941446411 },
                    { 202004, 102, 4123, new DateTime(1980, 10, 9, 0, 0, 0, 0, DateTimeKind.Unspecified), "Juan Contreras", "M", 941449542 },
                    { 202005, 101, 4124, new DateTime(1971, 2, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Ruben Hurtado", "M", 941449526 }
                });

            migrationBuilder.InsertData(
                table: "Pacientes",
                columns: new[] { "Id_pacientes", "Altura", "Antecedentes", "Apellido", "Correo", "DNI", "Direccion", "Id_historial", "Nacimiento", "Nombre", "Peso", "Sexo", "Telefono" },
                values: new object[] { 15020, 1.6499999999999999, "Cancer", "Burga", "sergioB@gmail.com", "76543210", "Calle La Libertad 124, La Molina", 851, new DateTime(2004, 10, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), "Sergio", 80.5, "M", "987654321" });

            migrationBuilder.InsertData(
                table: "Servicios",
                columns: new[] { "Id_serv", "Id_equipo", "Nom_serv" },
                values: new object[,]
                {
                    { 7001, 220, "Urgencias" },
                    { 7002, 221, "Pediatria" },
                    { 7003, 222, "Radiografias" },
                    { 7004, 223, "Dermatologia" },
                    { 7005, 224, "Terapia" },
                    { 7006, 225, "Medicina General" },
                    { 7007, 226, "Ambulancias" },
                    { 7008, 227, "Psicologia" },
                    { 7009, 228, "Ventanilla" },
                    { 7010, 229, "Triaje" }
                });

            migrationBuilder.InsertData(
                table: "Clinica_servicios",
                columns: new[] { "Id_clinica", "Id_serv", "Id_Clinica_servicios" },
                values: new object[,]
                {
                    { 101, 7001, 111 },
                    { 101, 7002, 112 },
                    { 101, 7005, 113 },
                    { 101, 7006, 114 },
                    { 101, 7007, 115 },
                    { 101, 7009, 116 },
                    { 101, 7010, 117 },
                    { 102, 7001, 118 },
                    { 102, 7002, 129 },
                    { 102, 7003, 120 },
                    { 102, 7004, 121 },
                    { 102, 7005, 122 },
                    { 102, 7006, 123 },
                    { 102, 7007, 124 },
                    { 102, 7008, 125 },
                    { 102, 7009, 126 },
                    { 102, 7010, 127 }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Citas",
                keyColumn: "Id_citas",
                keyValue: 9621);

            migrationBuilder.DeleteData(
                table: "Clinica_servicios",
                keyColumns: new[] { "Id_clinica", "Id_serv" },
                keyValues: new object[] { 101, 7001 });

            migrationBuilder.DeleteData(
                table: "Clinica_servicios",
                keyColumns: new[] { "Id_clinica", "Id_serv" },
                keyValues: new object[] { 101, 7002 });

            migrationBuilder.DeleteData(
                table: "Clinica_servicios",
                keyColumns: new[] { "Id_clinica", "Id_serv" },
                keyValues: new object[] { 101, 7005 });

            migrationBuilder.DeleteData(
                table: "Clinica_servicios",
                keyColumns: new[] { "Id_clinica", "Id_serv" },
                keyValues: new object[] { 101, 7006 });

            migrationBuilder.DeleteData(
                table: "Clinica_servicios",
                keyColumns: new[] { "Id_clinica", "Id_serv" },
                keyValues: new object[] { 101, 7007 });

            migrationBuilder.DeleteData(
                table: "Clinica_servicios",
                keyColumns: new[] { "Id_clinica", "Id_serv" },
                keyValues: new object[] { 101, 7009 });

            migrationBuilder.DeleteData(
                table: "Clinica_servicios",
                keyColumns: new[] { "Id_clinica", "Id_serv" },
                keyValues: new object[] { 101, 7010 });

            migrationBuilder.DeleteData(
                table: "Clinica_servicios",
                keyColumns: new[] { "Id_clinica", "Id_serv" },
                keyValues: new object[] { 102, 7001 });

            migrationBuilder.DeleteData(
                table: "Clinica_servicios",
                keyColumns: new[] { "Id_clinica", "Id_serv" },
                keyValues: new object[] { 102, 7002 });

            migrationBuilder.DeleteData(
                table: "Clinica_servicios",
                keyColumns: new[] { "Id_clinica", "Id_serv" },
                keyValues: new object[] { 102, 7003 });

            migrationBuilder.DeleteData(
                table: "Clinica_servicios",
                keyColumns: new[] { "Id_clinica", "Id_serv" },
                keyValues: new object[] { 102, 7004 });

            migrationBuilder.DeleteData(
                table: "Clinica_servicios",
                keyColumns: new[] { "Id_clinica", "Id_serv" },
                keyValues: new object[] { 102, 7005 });

            migrationBuilder.DeleteData(
                table: "Clinica_servicios",
                keyColumns: new[] { "Id_clinica", "Id_serv" },
                keyValues: new object[] { 102, 7006 });

            migrationBuilder.DeleteData(
                table: "Clinica_servicios",
                keyColumns: new[] { "Id_clinica", "Id_serv" },
                keyValues: new object[] { 102, 7007 });

            migrationBuilder.DeleteData(
                table: "Clinica_servicios",
                keyColumns: new[] { "Id_clinica", "Id_serv" },
                keyValues: new object[] { 102, 7008 });

            migrationBuilder.DeleteData(
                table: "Clinica_servicios",
                keyColumns: new[] { "Id_clinica", "Id_serv" },
                keyValues: new object[] { 102, 7009 });

            migrationBuilder.DeleteData(
                table: "Clinica_servicios",
                keyColumns: new[] { "Id_clinica", "Id_serv" },
                keyValues: new object[] { 102, 7010 });

            migrationBuilder.DeleteData(
                table: "Empleados",
                keyColumn: "Id_empleado",
                keyValue: 202001);

            migrationBuilder.DeleteData(
                table: "Empleados",
                keyColumn: "Id_empleado",
                keyValue: 202002);

            migrationBuilder.DeleteData(
                table: "Empleados",
                keyColumn: "Id_empleado",
                keyValue: 202003);

            migrationBuilder.DeleteData(
                table: "Empleados",
                keyColumn: "Id_empleado",
                keyValue: 202004);

            migrationBuilder.DeleteData(
                table: "Empleados",
                keyColumn: "Id_empleado",
                keyValue: 202005);

            migrationBuilder.DeleteData(
                table: "Especialidad",
                keyColumn: "Id_especialidad",
                keyValue: 4125);

            migrationBuilder.DeleteData(
                table: "Especialidad",
                keyColumn: "Id_especialidad",
                keyValue: 4126);

            migrationBuilder.DeleteData(
                table: "Especialidad",
                keyColumn: "Id_especialidad",
                keyValue: 4127);

            migrationBuilder.DeleteData(
                table: "Especialidad",
                keyColumn: "Id_especialidad",
                keyValue: 4128);

            migrationBuilder.DeleteData(
                table: "Especialidad",
                keyColumn: "Id_especialidad",
                keyValue: 4129);

            migrationBuilder.DeleteData(
                table: "Historial_Clinico",
                keyColumn: "Id_historial",
                keyValue: 852);

            migrationBuilder.DeleteData(
                table: "Pacientes",
                keyColumn: "Id_pacientes",
                keyValue: 15020);

            migrationBuilder.DeleteData(
                table: "Usuario",
                keyColumn: "Id_Usuario",
                keyValue: "admin");

            migrationBuilder.DeleteData(
                table: "Usuario",
                keyColumn: "Id_Usuario",
                keyValue: "LQuispe");

            migrationBuilder.DeleteData(
                table: "Usuario",
                keyColumn: "Id_Usuario",
                keyValue: "Spiderman");

            migrationBuilder.DeleteData(
                table: "Clinica",
                keyColumn: "Id_Clinica",
                keyValue: 101);

            migrationBuilder.DeleteData(
                table: "Clinica",
                keyColumn: "Id_Clinica",
                keyValue: 102);

            migrationBuilder.DeleteData(
                table: "Especialidad",
                keyColumn: "Id_especialidad",
                keyValue: 4120);

            migrationBuilder.DeleteData(
                table: "Especialidad",
                keyColumn: "Id_especialidad",
                keyValue: 4121);

            migrationBuilder.DeleteData(
                table: "Especialidad",
                keyColumn: "Id_especialidad",
                keyValue: 4122);

            migrationBuilder.DeleteData(
                table: "Especialidad",
                keyColumn: "Id_especialidad",
                keyValue: 4123);

            migrationBuilder.DeleteData(
                table: "Especialidad",
                keyColumn: "Id_especialidad",
                keyValue: 4124);

            migrationBuilder.DeleteData(
                table: "Historial_Clinico",
                keyColumn: "Id_historial",
                keyValue: 851);

            migrationBuilder.DeleteData(
                table: "Servicios",
                keyColumn: "Id_serv",
                keyValue: 7001);

            migrationBuilder.DeleteData(
                table: "Servicios",
                keyColumn: "Id_serv",
                keyValue: 7002);

            migrationBuilder.DeleteData(
                table: "Servicios",
                keyColumn: "Id_serv",
                keyValue: 7003);

            migrationBuilder.DeleteData(
                table: "Servicios",
                keyColumn: "Id_serv",
                keyValue: 7004);

            migrationBuilder.DeleteData(
                table: "Servicios",
                keyColumn: "Id_serv",
                keyValue: 7005);

            migrationBuilder.DeleteData(
                table: "Servicios",
                keyColumn: "Id_serv",
                keyValue: 7006);

            migrationBuilder.DeleteData(
                table: "Servicios",
                keyColumn: "Id_serv",
                keyValue: 7007);

            migrationBuilder.DeleteData(
                table: "Servicios",
                keyColumn: "Id_serv",
                keyValue: 7008);

            migrationBuilder.DeleteData(
                table: "Servicios",
                keyColumn: "Id_serv",
                keyValue: 7009);

            migrationBuilder.DeleteData(
                table: "Servicios",
                keyColumn: "Id_serv",
                keyValue: 7010);

            migrationBuilder.DeleteData(
                table: "Equipo_produccion",
                keyColumn: "Id_equipo",
                keyValue: 220);

            migrationBuilder.DeleteData(
                table: "Equipo_produccion",
                keyColumn: "Id_equipo",
                keyValue: 221);

            migrationBuilder.DeleteData(
                table: "Equipo_produccion",
                keyColumn: "Id_equipo",
                keyValue: 222);

            migrationBuilder.DeleteData(
                table: "Equipo_produccion",
                keyColumn: "Id_equipo",
                keyValue: 223);

            migrationBuilder.DeleteData(
                table: "Equipo_produccion",
                keyColumn: "Id_equipo",
                keyValue: 224);

            migrationBuilder.DeleteData(
                table: "Equipo_produccion",
                keyColumn: "Id_equipo",
                keyValue: 225);

            migrationBuilder.DeleteData(
                table: "Equipo_produccion",
                keyColumn: "Id_equipo",
                keyValue: 226);

            migrationBuilder.DeleteData(
                table: "Equipo_produccion",
                keyColumn: "Id_equipo",
                keyValue: 227);

            migrationBuilder.DeleteData(
                table: "Equipo_produccion",
                keyColumn: "Id_equipo",
                keyValue: 228);

            migrationBuilder.DeleteData(
                table: "Equipo_produccion",
                keyColumn: "Id_equipo",
                keyValue: 229);
        }
    }
}
